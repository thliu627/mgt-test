package com.sunmi.common.webdriver;

/**
 * @author thliu@credit2go.cn
 * @date 2019/3/27 0:17
 */
public class FireFoxDriverLoader {
}
