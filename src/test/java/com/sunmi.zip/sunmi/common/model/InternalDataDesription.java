package com.sunmi.common.model;

/**
 * @author thliu@credit2go.cn
 * @date 2019/3/28 22:57
 */
public class InternalDataDesription {

    private Boolean partnerData;
    private Boolean appData;
    private Boolean deviceData;
    private Boolean financeData;
    private String department;
    private String name;
    private String mobile;
    private String email;


}
